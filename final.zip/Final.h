#ifndef FINAL_H
#define FINAL_H

#include <stack>
#include "Room.h"
#include "LockedRoom.h"
#include "MirroredRoom.h"
#include "Carosel.h"
#include "Item.h"
#include "time.h"
#include "Inventory.h"
Room* makeMaze(std::vector <Room*>&);

#endif
