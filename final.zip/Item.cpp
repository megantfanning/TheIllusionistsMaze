#include "Item.h"

Item::Item(string label,int key):label(label),key(key){}

